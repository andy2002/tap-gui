# yelb system

The Yelb system is composed of four parts: `yelb-appserver`, `yelb-ui`, `yelb-db`, and `redis-server`.

# yelb

This sample catalog and documentation corresponds to a demonstration application called [Yelb](https://github.com/mreferre/yelb).