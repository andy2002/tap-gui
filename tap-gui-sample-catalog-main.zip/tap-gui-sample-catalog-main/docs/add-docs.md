# How to add new documentation

To get started adding documentation to your system, please see [this documentation](https://backstage.io/docs/features/techdocs/creating-and-publishing#manually-add-documentation-setup-to-already-existing-repository) for more information.

# How to write markdown syntax
To create beautiful documentation with markdown, please see [this link](https://www.markdownguide.org/cheat-sheet/) for details.
