# yelb db

A Postgres backend database that is used to persist the votes. The `yelb-db` container image is nothing more than Postgres customized to create the database schema the application relies on.

# yelb

This sample catalog and documentation corresponds to a demonstration application called [Yelb](https://github.com/mreferre/yelb).