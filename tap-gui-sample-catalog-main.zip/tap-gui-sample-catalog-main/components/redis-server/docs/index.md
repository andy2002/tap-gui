# redis server

Redis is used to store the number of page views.

# What is Redis?
Redis is an in-memory data structure store, used as a distributed, in-memory key–value database, cache and message broker, with optional durability. Redis supports different kinds of abstract data structures, such as strings, lists, maps, sets, sorted sets, HyperLogLogs, bitmaps, streams, and spatial indices.

# yelb

This sample catalog and documentation corresponds to a demonstration application called [Yelb](https://github.com/mreferre/yelb).