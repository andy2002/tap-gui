# yelb application database

Resources are the infrastructure a component needs to operate at runtime. The `yelb application database` is the physical or virtual infrastructure needed to operate the database.

# yelb

This sample catalog and documentation corresponds to a demonstration application called [Yelb](https://github.com/mreferre/yelb).